class AuthService {
  const AuthService._();
}
